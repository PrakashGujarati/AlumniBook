<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UserRegister extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_register', function (Blueprint $table) {
            $table->increments('id');
            $table->string('user_id');
            $table->string('password');
            $table->string('surname');
            $table->string('name');
            $table->string('father_mother_name');
            $table->integer('study_year');
            $table->string('obtained_degree');
            $table->text('further_study');
            $table->text('present_occuption');
            $table->text('current_position');
            $table->text('office_address');
            $table->date('dob');
            $table->char('gender');
            $table->string('marital_status');
            $table->string('residential_address');
            $table->bigInteger('cell_phone');
            $table->text('facebook_url');
            $table->text('twitter_url');
            $table->longText('success_role_of_college');
            $table->longText('college_experience');
            $table->date('created_at');
            $table->date('deleted_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
