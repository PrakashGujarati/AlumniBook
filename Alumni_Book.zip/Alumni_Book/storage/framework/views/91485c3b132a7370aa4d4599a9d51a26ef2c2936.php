<!DOCTYPE html>
<html>
<head>
    <title>Alimni Book - <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Font Awesome CSS-->
    <link href="<?php echo e(asset('assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- Mobile Menu Css -->
    <link href="<?php echo e(asset('assets/menu/css/meanmenu.css')); ?>" rel="stylesheet">
    <!-- Owl Carousel -->
    <link href="<?php echo e(asset('assets/owl-carousel/css/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/owl-carousel/css/owl.theme.css')); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.png')); ?>">
</head>
<body>
    <?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
</body>
</html>